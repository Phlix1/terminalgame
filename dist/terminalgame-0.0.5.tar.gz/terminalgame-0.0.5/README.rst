============
Terminalgame
============

Terminalgame is a Python wrapper module for developing games. It contains python functions and classes that will allow you to use terminal display and keyboard. It requires curses module and pynput.